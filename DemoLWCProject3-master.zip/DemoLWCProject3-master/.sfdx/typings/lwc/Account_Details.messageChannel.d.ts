declare module "@salesforce/messageChannel/Account_Details__c" {
    var Account_Details: string;
    export default Account_Details;
}