declare module "@salesforce/messageChannel/Account_More_Info__c" {
    var Account_More_Info: string;
    export default Account_More_Info;
}