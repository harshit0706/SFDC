declare module "@salesforce/messageChannel/Count_Updated__c" {
    var Count_Updated: string;
    export default Count_Updated;
}