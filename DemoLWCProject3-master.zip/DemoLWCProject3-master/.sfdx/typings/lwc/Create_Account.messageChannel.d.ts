declare module "@salesforce/messageChannel/Create_Account__c" {
    var Create_Account: string;
    export default Create_Account;
}