import { LightningElement } from 'lwc';

export default class TestLWCCreationFromCLI extends LightningElement {}